package com.jedy.mod;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * Executa as "funções" do addon original (já convertidas de Bedrock para Java).
 * Cada linha roda sozinha: se uma linha falhar, as outras continuam.
 */
public final class FunctionRunner {
    private FunctionRunner() {}

    private static Map<String, List<String>> FUNCS = new HashMap<>();
    private static int depth = 0;

    public static void load() {
        try (InputStream in = FunctionRunner.class.getResourceAsStream("/jedy_functions.json")) {
            if (in == null) return;
            Type type = new TypeToken<Map<String, List<String>>>() {}.getType();
            Map<String, List<String>> m =
                    new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), type);
            if (m != null) FUNCS = m;
        } catch (Exception e) {
            throw new RuntimeException("Falha ao ler jedy_functions.json", e);
        }
    }

    /** Roda a função como se o jogador a tivesse executado (com permissão total, sem spam no chat). */
    public static void runAsPlayer(ServerPlayer player, String name) {
        CommandSourceStack src = player.createCommandSourceStack().withPermission(4).withSuppressedOutput();
        run(player.server, src, name);
    }

    public static void run(MinecraftServer server, CommandSourceStack source, String name) {
        List<String> lines = FUNCS.get(name.trim().toLowerCase(Locale.ROOT));
        if (lines == null || depth > 8) return;
        depth++;
        try {
            for (String line : lines) {
                try {
                    server.getCommands().getDispatcher().execute(line, source);
                } catch (Exception ignored) {
                    // linha que não deu certo: segue para a próxima
                }
            }
        } finally {
            depth--;
        }
    }
}

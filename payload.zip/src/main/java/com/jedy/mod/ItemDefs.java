package com.jedy.mod;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

/** Lê o jedy_items.json (gerado a partir do addon Bedrock). */
public final class ItemDefs {
    private ItemDefs() {}

    public static class Effect {
        public String id;
        public float chance;
        public int ticks;
        public int amp;
    }

    public static class Food {
        public int nutrition;
        public float saturation;
        public boolean always;
        public List<Effect> effects = new ArrayList<>();
    }

    public static class Def {
        public String name;
        public int stack = 64;
        public int durability;
        public double damage;
        public boolean handheld;
        public boolean foil;
        public String slot;      // head | chest | legs | feet | null
        public Food food;        // null se não for comida
        public List<String> lore = new ArrayList<>();
        public String tab;
        public String function;  // função do addon original executada ao usar (ou null)
        public float cooldown;   // recarga em segundos
        public boolean action;   // true = no addon tinha script/função (ainda sem efeito)
    }

    public static class TabDef {
        public String id;
        public List<String> items = new ArrayList<>();
    }

    public static class Manifest {
        public List<Def> items = new ArrayList<>();
        public List<TabDef> tabs = new ArrayList<>();
    }

    public static Manifest load() {
        try (InputStream in = ItemDefs.class.getResourceAsStream("/jedy_items.json")) {
            if (in == null) throw new IllegalStateException("jedy_items.json não encontrado");
            return new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), Manifest.class);
        } catch (Exception e) {
            throw new RuntimeException("Falha ao ler jedy_items.json", e);
        }
    }
}

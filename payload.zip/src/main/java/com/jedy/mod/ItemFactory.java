package com.jedy.mod;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.ItemAttributeModifiers;

/** Converte uma definição do manifesto em um Item de verdade. */
public final class ItemFactory {
    private ItemFactory() {}

    public static Item create(ItemDefs.Def d) {
        Item.Properties p = new Item.Properties();

        if (d.durability > 0) {
            p.durability(d.durability);
        } else {
            p.stacksTo(Math.max(1, Math.min(99, d.stack)));
        }

        if (d.foil) {
            p.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        }

        if (d.damage > 0) {
            p.attributes(ItemAttributeModifiers.builder()
                    .add(Attributes.ATTACK_DAMAGE,
                            new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, d.damage - 1.0,
                                    AttributeModifier.Operation.ADD_VALUE),
                            EquipmentSlotGroup.MAINHAND)
                    .add(Attributes.ATTACK_SPEED,
                            new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -2.4,
                                    AttributeModifier.Operation.ADD_VALUE),
                            EquipmentSlotGroup.MAINHAND)
                    .build());
        }

        if (d.food != null) {
            FoodProperties.Builder fb = new FoodProperties.Builder()
                    .nutrition(Math.max(0, d.food.nutrition))
                    .saturationModifier(d.food.saturation);
            if (d.food.always) fb.alwaysEdible();
            for (ItemDefs.Effect e : d.food.effects) {
                var holder = BuiltInRegistries.MOB_EFFECT.getHolder(ResourceLocation.withDefaultNamespace(e.id));
                if (holder.isPresent()) {
                    fb.effect(new MobEffectInstance(holder.get(), e.ticks, e.amp), e.chance);
                }
            }
            p.food(fb.build());
        }

        if (d.slot != null) {
            EquipmentSlot slot = switch (d.slot) {
                case "chest" -> EquipmentSlot.CHEST;
                case "legs" -> EquipmentSlot.LEGS;
                case "feet" -> EquipmentSlot.FEET;
                default -> EquipmentSlot.HEAD;
            };
            return new WearableItem(p, d.lore, slot);
        }
        return new JedyItem(p, d.lore);
    }
}

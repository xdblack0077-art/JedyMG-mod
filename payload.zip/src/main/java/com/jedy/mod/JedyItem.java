package com.jedy.mod;

import java.util.List;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** Item comum do addon: só adiciona as linhas de descrição (lore) do original. */
public class JedyItem extends Item {
    private final List<String> lore;

    public JedyItem(Properties properties, List<String> lore) {
        super(properties);
        this.lore = lore;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        for (String line : lore) {
            tooltip.add(Component.literal(line));
        }
    }
}

package com.jedy.mod;

import java.util.List;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Item do addon: descrição (lore) e, se tiver, executa a função do original ao usar. */
public class JedyItem extends Item {
    protected final List<String> lore;
    protected final String function;
    protected final int cooldownTicks;

    public JedyItem(Properties properties, List<String> lore, String function, int cooldownTicks) {
        super(properties);
        this.lore = lore;
        this.function = function;
        this.cooldownTicks = cooldownTicks;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (function == null) {
            return super.use(level, player, hand);
        }
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            if (cooldownTicks > 0) {
                player.getCooldowns().addCooldown(this, cooldownTicks);
            }
            FunctionRunner.runAsPlayer(sp, function);
        }
        if (stack.has(DataComponents.FOOD)) {
            return super.use(level, player, hand);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context,
                                List<Component> tooltip, TooltipFlag flag) {
        for (String line : lore) {
            tooltip.add(Component.literal(line));
        }
    }
}

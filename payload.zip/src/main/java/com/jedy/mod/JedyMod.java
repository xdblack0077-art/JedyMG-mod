package com.jedy.mod;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.minecraft.commands.Commands;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(JedyMod.MODID)
public class JedyMod {
    public static final String MODID = "jedy";

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    /** Todos os itens registrados, pelo nome (ex.: "manto_shukaku1"). */
    public static final Map<String, RegistryObject<Item>> ALL = new LinkedHashMap<>();

    public JedyMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        FunctionRunner.load();
        if (FMLEnvironment.dist == Dist.CLIENT) {
            com.jedy.mod.client.ClientSetup.init();
        }
        MinecraftForge.EVENT_BUS.addListener(JedyMod::onRegisterCommands);

        ItemDefs.Manifest manifest = ItemDefs.load();

        for (ItemDefs.Def def : manifest.items) {
            ALL.put(def.name, ITEMS.register(def.name, () -> ItemFactory.create(def)));
        }

        for (ItemDefs.TabDef tab : manifest.tabs) {
            final List<String> names = tab.items;
            if (names.isEmpty()) continue;
            TABS.register(tab.id, () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + MODID + "." + tab.id))
                    .icon(() -> {
                        RegistryObject<Item> first = ALL.get(names.get(0));
                        return first != null ? new ItemStack(first.get()) : new ItemStack(Items.PAPER);
                    })
                    .displayItems((params, output) -> {
                        for (String n : names) {
                            RegistryObject<Item> ro = ALL.get(n);
                            if (ro != null) output.accept(ro.get());
                        }
                    })
                    .build());
        }

        ITEMS.register(bus);
        TABS.register(bus);
    }

    /** /jedyfn <nome>: roda uma função do addon (usado por dentro das funções convertidas). */
    private static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("jedyfn")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("name", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            FunctionRunner.run(ctx.getSource().getServer(), ctx.getSource(),
                                    StringArgumentType.getString(ctx, "name"));
                            return 1;
                        })));
    }
}

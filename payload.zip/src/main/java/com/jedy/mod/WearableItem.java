package com.jedy.mod;

import java.util.List;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Item vestível (roupa/manto/acessório): botão direito equipa no slot certo. */
public class WearableItem extends JedyItem implements Equipable {
    private final EquipmentSlot slot;

    public WearableItem(Properties properties, List<String> lore, EquipmentSlot slot) {
        super(properties, lore);
        this.slot = slot;
    }

    @Override
    public EquipmentSlot getEquipmentSlot() {
        return slot;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return swapWithEquipmentSlot(this, level, player, hand);
    }
}

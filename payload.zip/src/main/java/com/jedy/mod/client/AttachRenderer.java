package com.jedy.mod.client;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.joml.Quaternionf;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jedy.mod.JedyMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.common.MinecraftForge;

/** Desenha os modelos 3D (Susanoo, mantos, roupas...) em volta do jogador que veste o item. */
public final class AttachRenderer {
    private AttachRenderer() {}

    private static Map<String, List<List<String>>> ATTACH = new HashMap<>();
    private static final Map<String, GeoData> CACHE = new HashMap<>();
    private static final Map<String, Boolean> FAILED = new HashMap<>();

    private static final EquipmentSlot[] SLOTS = {
        EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };

    public static void init() {
        try (InputStream in = AttachRenderer.class.getResourceAsStream("/jedy_attach.json")) {
            if (in != null) {
                Type type = new TypeToken<Map<String, List<List<String>>>>() {}.getType();
                Map<String, List<List<String>>> m =
                        new Gson().fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), type);
                if (m != null) ATTACH = m;
            }
        } catch (Exception e) {
            throw new RuntimeException("Falha ao ler jedy_attach.json", e);
        }
        MinecraftForge.EVENT_BUS.addListener(AttachRenderer::onRenderPlayer);
    }

    private static GeoData geo(String name) {
        if (FAILED.containsKey(name)) return null;
        GeoData g = CACHE.get(name);
        if (g == null) {
            try {
                g = GeoData.load(name);
                CACHE.put(name, g);
            } catch (Exception e) {
                FAILED.put(name, Boolean.TRUE);
                return null;
            }
        }
        return g;
    }

    private static void onRenderPlayer(RenderPlayerEvent.Post event) {
        Player player = event.getEntity();
        if (player.isInvisible()) return;
        Pose pose = player.getPose();
        if (pose != Pose.STANDING && pose != Pose.CROUCHING) return;

        List<List<String>> pairs = new ArrayList<>();
        for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = player.getItemBySlot(slot);
            if (stack.isEmpty()) continue;
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(stack.getItem());
            if (!JedyMod.MODID.equals(key.getNamespace())) continue;
            List<List<String>> p = ATTACH.get(key.getPath());
            if (p != null) pairs.addAll(p);
        }
        if (pairs.isEmpty()) return;

        PoseStack ps = event.getPoseStack();
        MultiBufferSource buffer = event.getMultiBufferSource();
        int light = event.getPackedLight();
        PlayerModel<AbstractClientPlayer> model = event.getRenderer().getModel();

        ps.pushPose();
        float bodyRot = Mth.rotLerp(event.getPartialTick(), player.yBodyRotO, player.yBodyRot);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - bodyRot));
        ps.scale(-1.0F, -1.0F, 1.0F);
        ps.scale(0.9375F, 0.9375F, 0.9375F);
        ps.translate(0.0F, -1.501F, 0.0F);

        for (List<String> pair : pairs) {
            GeoData g = geo(pair.get(0));
            if (g == null) continue;
            ResourceLocation tex = ResourceLocation.fromNamespaceAndPath(
                    JedyMod.MODID, "textures/model/" + pair.get(1) + ".png");
            VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(tex));
            for (GeoData.Bone root : g.roots) {
                renderBone(ps, vc, light, model, root);
            }
        }
        ps.popPose();
    }

    private static ModelPart vanillaPart(PlayerModel<AbstractClientPlayer> m, int id) {
        switch (id) {
            case GeoData.HEAD: return m.head;
            case GeoData.BODY: return m.body;
            case GeoData.RIGHT_ARM: return m.rightArm;
            case GeoData.LEFT_ARM: return m.leftArm;
            case GeoData.RIGHT_LEG: return m.rightLeg;
            case GeoData.LEFT_LEG: return m.leftLeg;
            default: return null;
        }
    }

    private static void renderBone(PoseStack ps, VertexConsumer vc, int light,
                                   PlayerModel<AbstractClientPlayer> model, GeoData.Bone b) {
        ps.pushPose();
        ModelPart vp = vanillaPart(model, b.vanilla);
        if (vp != null) {
            vp.translateAndRotate(ps);
        } else {
            ps.translate(b.px / 16.0F, b.py / 16.0F, b.pz / 16.0F);
            if (b.rx != 0.0F || b.ry != 0.0F || b.rz != 0.0F) {
                ps.mulPose(new Quaternionf().rotationZYX(b.rz, b.ry, b.rx));
            }
        }
        ps.translate(-b.px / 16.0F, -b.py / 16.0F, -b.pz / 16.0F);

        PoseStack.Pose pose = ps.last();
        for (int q = 0; q < b.quads; q++) {
            int po = q * 12, uo = q * 8, no = q * 3;
            float nx = b.nrm[no] / 127.0F, ny = b.nrm[no + 1] / 127.0F, nz = b.nrm[no + 2] / 127.0F;
            for (int v = 0; v < 4; v++) {
                vc.addVertex(pose, b.pos[po + v * 3] / 512.0F, b.pos[po + v * 3 + 1] / 512.0F,
                                b.pos[po + v * 3 + 2] / 512.0F)
                        .setColor(255, 255, 255, 255)
                        .setUv(b.uv[uo + v * 2] / 2048.0F, b.uv[uo + v * 2 + 1] / 2048.0F)
                        .setOverlay(OverlayTexture.NO_OVERLAY)
                        .setLight(light)
                        .setNormal(pose, nx, ny, nz);
            }
        }
        for (GeoData.Bone c : b.children) {
            renderBone(ps, vc, light, model, c);
        }
        ps.popPose();
    }
}

package com.jedy.mod.client;

/** Só é carregada no cliente (jogo), nunca em servidor dedicado. */
public final class ClientSetup {
    private ClientSetup() {}

    public static void init() {
        AttachRenderer.init();
    }
}

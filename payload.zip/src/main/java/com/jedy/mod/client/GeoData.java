package com.jedy.mod.client;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Modelo 3D (convertido do Bedrock): ossos e quadrados prontos para desenhar. */
public final class GeoData {
    public static final int NONE = 0, HEAD = 1, BODY = 2, RIGHT_ARM = 3, LEFT_ARM = 4, RIGHT_LEG = 5, LEFT_LEG = 6;

    public static final class Bone {
        public String name;
        public String parent;
        public float px, py, pz;   // pivot (pixels, quadro Java)
        public float rx, ry, rz;   // rotação do osso (radianos)
        public int quads;
        public short[] pos;        // 12 por quad (x,y,z de 4 vértices), pixels * 32
        public short[] uv;         // 8 por quad, u/v * 2048
        public byte[] nrm;         // 3 por quad, * 127
        public int vanilla = NONE;
        public final List<Bone> children = new ArrayList<>();
    }

    public final List<Bone> roots = new ArrayList<>();

    public static GeoData load(String name) throws IOException {
        try (InputStream raw = GeoData.class.getResourceAsStream("/assets/jedy/geo/" + name + ".bin")) {
            if (raw == null) throw new IOException("modelo não encontrado: " + name);
            DataInputStream in = new DataInputStream(new BufferedInputStream(raw));
            int nb = in.readUnsignedShort();
            List<Bone> all = new ArrayList<>();
            Map<String, Bone> byName = new HashMap<>();
            for (int i = 0; i < nb; i++) {
                Bone b = new Bone();
                b.name = in.readUTF();
                b.parent = in.readUTF();
                b.px = in.readFloat(); b.py = in.readFloat(); b.pz = in.readFloat();
                b.rx = in.readFloat(); b.ry = in.readFloat(); b.rz = in.readFloat();
                b.quads = in.readInt();
                b.pos = new short[b.quads * 12];
                b.uv = new short[b.quads * 8];
                b.nrm = new byte[b.quads * 3];
                for (int q = 0; q < b.quads; q++) {
                    for (int k = 0; k < 12; k++) b.pos[q * 12 + k] = in.readShort();
                    for (int k = 0; k < 8; k++) b.uv[q * 8 + k] = in.readShort();
                    for (int k = 0; k < 3; k++) b.nrm[q * 3 + k] = in.readByte();
                }
                b.vanilla = vanillaId(b.name);
                all.add(b);
                byName.put(b.name, b);
            }
            GeoData g = new GeoData();
            for (Bone b : all) {
                Bone p = (b.parent == null || b.parent.isEmpty()) ? null : byName.get(b.parent);
                if (p == null || p == b) g.roots.add(b); else p.children.add(b);
            }
            return g;
        }
    }

    private static int vanillaId(String name) {
        switch (name.toLowerCase(Locale.ROOT)) {
            case "head": return HEAD;
            case "body": case "waist": return BODY;
            case "rightarm": return RIGHT_ARM;
            case "leftarm": return LEFT_ARM;
            case "rightleg": return RIGHT_LEG;
            case "leftleg": return LEFT_LEG;
            default: return NONE;
        }
    }
}
